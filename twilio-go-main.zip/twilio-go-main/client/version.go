// Package config for config files.
package client

// LibraryVersion specifies the current version of twilio-go.
const LibraryVersion = "0.17.0"
