# ApiV2010AccountAvailablePhoneNumberCountryAvailablePhoneNumberLocalCapabilities

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Fax** | **bool** |  |[optional] 
**Mms** | **bool** |  |[optional] 
**Sms** | **bool** |  |[optional] 
**Voice** | **bool** |  |[optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


