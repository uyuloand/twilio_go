# ListSipCredentialListMappingResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CredentialListMappings** | [**[]ApiV2010SipCredentialListMapping**](ApiV2010SipCredentialListMapping.md) |  |[optional] 
**End** | **int** |  |[optional] 
**FirstPageUri** | **string** |  |[optional] 
**NextPageUri** | **string** |  |[optional] 
**Page** | **int** |  |[optional] 
**PageSize** | **int** |  |[optional] 
**PreviousPageUri** | **string** |  |[optional] 
**Start** | **int** |  |[optional] 
**Uri** | **string** |  |[optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


