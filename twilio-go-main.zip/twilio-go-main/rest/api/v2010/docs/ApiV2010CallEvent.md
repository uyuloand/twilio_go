# ApiV2010CallEvent

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Request** | Pointer to **map[string]interface{}** | Call Request. |
**Response** | Pointer to **map[string]interface{}** | Call Response with Events. |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


