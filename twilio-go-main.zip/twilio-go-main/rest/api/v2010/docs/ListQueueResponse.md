# ListQueueResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**End** | **int** |  |[optional] 
**FirstPageUri** | **string** |  |[optional] 
**NextPageUri** | **string** |  |[optional] 
**Page** | **int** |  |[optional] 
**PageSize** | **int** |  |[optional] 
**PreviousPageUri** | **string** |  |[optional] 
**Queues** | [**[]ApiV2010Queue**](ApiV2010Queue.md) |  |[optional] 
**Start** | **int** |  |[optional] 
**Uri** | **string** |  |[optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


