# ListParticipantResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**End** | **int** |  |[optional] 
**FirstPageUri** | **string** |  |[optional] 
**NextPageUri** | **string** |  |[optional] 
**Page** | **int** |  |[optional] 
**PageSize** | **int** |  |[optional] 
**Participants** | [**[]ApiV2010Participant**](ApiV2010Participant.md) |  |[optional] 
**PreviousPageUri** | **string** |  |[optional] 
**Start** | **int** |  |[optional] 
**Uri** | **string** |  |[optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


