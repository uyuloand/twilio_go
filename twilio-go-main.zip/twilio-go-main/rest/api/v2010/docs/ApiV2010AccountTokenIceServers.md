# ApiV2010AccountTokenIceServers

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Credential** | **string** |  |[optional] 
**Url** | **string** |  |[optional] 
**Urls** | **string** |  |[optional] 
**Username** | **string** |  |[optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


