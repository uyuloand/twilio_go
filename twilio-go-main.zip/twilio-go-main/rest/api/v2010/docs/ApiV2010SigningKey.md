# ApiV2010SigningKey

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DateCreated** | Pointer to **string** |  |
**DateUpdated** | Pointer to **string** |  |
**FriendlyName** | Pointer to **string** |  |
**Sid** | Pointer to **string** |  |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


