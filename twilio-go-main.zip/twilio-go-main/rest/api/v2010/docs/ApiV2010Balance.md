# ApiV2010Balance

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccountSid** | Pointer to **string** | Account Sid. |
**Balance** | Pointer to **string** | Account balance |
**Currency** | Pointer to **string** | Currency units |

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


