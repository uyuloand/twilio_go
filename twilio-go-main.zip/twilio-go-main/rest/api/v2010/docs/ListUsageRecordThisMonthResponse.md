# ListUsageRecordThisMonthResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**End** | **int** |  |[optional] 
**FirstPageUri** | **string** |  |[optional] 
**NextPageUri** | **string** |  |[optional] 
**Page** | **int** |  |[optional] 
**PageSize** | **int** |  |[optional] 
**PreviousPageUri** | **string** |  |[optional] 
**Start** | **int** |  |[optional] 
**Uri** | **string** |  |[optional] 
**UsageRecords** | [**[]ApiV2010UsageRecordThisMonth**](ApiV2010UsageRecordThisMonth.md) |  |[optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


