# ListCredentialAwsResponseMeta

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FirstPageUrl** | **string** |  |[optional] 
**Key** | **string** |  |[optional] 
**NextPageUrl** | **string** |  |[optional] 
**Page** | **int** |  |[optional] 
**PageSize** | **int** |  |[optional] 
**PreviousPageUrl** | **string** |  |[optional] 
**Url** | **string** |  |[optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


