# ListCredentialAwsResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Credentials** | [**[]AccountsV1CredentialAws**](AccountsV1CredentialAws.md) |  |[optional] 
**Meta** | [**ListCredentialAwsResponseMeta**](ListCredentialAwsResponseMeta.md) |  |[optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


